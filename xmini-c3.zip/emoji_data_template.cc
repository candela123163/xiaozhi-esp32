#include "emoji_data.h"

namespace bitmap_emoji {

// 注意：以下数组需要从实际转换的图片生成
// 这里只是示例结构

// 开心表情 - 需要从实际图片转换
const uint8_t happy_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_smile.png 120 生成
    // 然后将生成的数组复制到这里
};

// 悲伤表情 - 需要从实际图片转换  
const uint8_t sad_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_sad.png 120 生成
    // 然后将生成的数组复制到这里
};

// 思考表情 - 需要从实际图片转换
const uint8_t thinking_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_thinking.png 120 生成
    // 然后将生成的数组复制到这里
};

// 眨眼动画 - 5帧动画示例
const uint8_t blink_frame1[EMOJI_DATA_SIZE] = {
    // 全亮帧 - 睁眼状态
};

const uint8_t blink_frame2[EMOJI_DATA_SIZE] = {
    // 半闭眼帧
};

const uint8_t blink_frame3[EMOJI_DATA_SIZE] = {
    // 闭眼帧
};

const uint8_t blink_frame4[EMOJI_DATA_SIZE] = {
    // 半闭眼帧
};

const uint8_t blink_frame5[EMOJI_DATA_SIZE] = {
    // 全亮帧 - 睁眼状态
};

} // namespace bitmap_emoji
