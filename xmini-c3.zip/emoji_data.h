#pragma once

#include <stdint.h>

namespace bitmap_emoji {

// 表情位图数据定义
// 所有位图都是32x32像素，1位单色格式
// 数据按SSD1306垂直排列格式存储

// 开心表情 - 单帧
extern const uint8_t happy_face[];

// 悲伤表情 - 单帧  
extern const uint8_t sad_face[];

// 思考表情 - 单帧
extern const uint8_t thinking_face[];

// 眨眼动画 - 5帧动画示例
extern const uint8_t blink_frame1[];  // 睁眼
extern const uint8_t blink_frame2[];  // 半闭眼
extern const uint8_t blink_frame3[];  // 闭眼
extern const uint8_t blink_frame4[];  // 半闭眼
extern const uint8_t blink_frame5[];  // 睁眼

// 心跳动画 - 5帧动画示例
extern const uint8_t heartbeat_frame1[];  // 小
extern const uint8_t heartbeat_frame2[];  // 中
extern const uint8_t heartbeat_frame3[];  // 大
extern const uint8_t heartbeat_frame4[];  // 中
extern const uint8_t heartbeat_frame5[];  // 小

// 位图数据大小常量 - 使用屏幕分辨率
constexpr uint16_t EMOJI_WIDTH = 128;
constexpr uint16_t EMOJI_HEIGHT = 64;
constexpr size_t EMOJI_DATA_SIZE = (EMOJI_WIDTH * EMOJI_HEIGHT) / 8;  // 1024字节

} // namespace bitmap_emoji
