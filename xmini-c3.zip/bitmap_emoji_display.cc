#include "bitmap_emoji_display.h"
#include "emoji_data.h"
#include <esp_log.h>
#include <cstring>
#include <unordered_map>

static const char *TAG = "bitmap_emoji";

namespace bitmap_emoji {

// BitmapEmojiPlayer实现
BitmapEmojiPlayer::BitmapEmojiPlayer(esp_lcd_panel_handle_t panel, esp_lcd_panel_io_handle_t panel_io)
    : panel_(panel), panel_io_(panel_io), timer_(nullptr), is_initialized_(false) {
    
    ESP_LOGI(TAG, "Create BitmapEmojiPlayer, panel: %p, panel_io: %p", panel, panel_io);
    
    // 创建定时器
    esp_timer_create_args_t timer_args = {
        .callback = TimerCallback,
        .name = "emoji_timer",
        .arg = this
    };
    
    if (esp_timer_create(&timer_args, &timer_) == ESP_OK) {
        is_initialized_ = true;
        ESP_LOGI(TAG, "BitmapEmojiPlayer initialized successfully");
    } else {
        ESP_LOGE(TAG, "Failed to create emoji timer");
    }
}

BitmapEmojiPlayer::~BitmapEmojiPlayer() {
    if (timer_) {
        esp_timer_stop(timer_);
        esp_timer_delete(timer_);
        timer_ = nullptr;
    }
}

void BitmapEmojiPlayer::PlayAnimation(const EmojiAnimation& animation) {
    if (!is_initialized_ || !timer_) {
        ESP_LOGE(TAG, "Player not initialized");
        return;
    }
    
    // 停止当前动画
    esp_timer_stop(timer_);
    
    // 设置新动画
    current_animation_ = animation;
    current_animation_.set_current_frame(0);
    current_animation_.set_is_playing(true);
    
    // 计算定时器间隔 (微秒)
    uint64_t interval_us = (1000000ULL / current_animation_.fps());
    
    // 启动定时器
    if (esp_timer_start_periodic(timer_, interval_us) == ESP_OK) {
        ESP_LOGI(TAG, "Animation started: %d frames, %d fps", 
                current_animation_.frame_count(), current_animation_.fps());
    } else {
        ESP_LOGE(TAG, "Failed to start animation timer");
    }
}

void BitmapEmojiPlayer::StopAnimation() {
    if (timer_) {
        esp_timer_stop(timer_);
        current_animation_.set_is_playing(false);
        ESP_LOGI(TAG, "Animation stopped");
    }
}

void BitmapEmojiPlayer::SetBitmap(const uint8_t* bitmap_data, uint16_t width, uint16_t height) {
    if (!is_initialized_ || !bitmap_data) {
        return;
    }
    
    // 停止动画
    StopAnimation();
    
    // 直接绘制位图
    esp_lcd_panel_draw_bitmap(panel_, 0, 0, width, height, bitmap_data);
}

void BitmapEmojiPlayer::ClearScreen() {
    if (!is_initialized_) {
        return;
    }
    
    // 创建全黑位图数据
    static uint8_t black_screen[128 * 64 / 8] = {0};
    esp_lcd_panel_draw_bitmap(panel_, 0, 0, 128, 64, black_screen);
}

void BitmapEmojiPlayer::TimerCallback(void* arg) {
    auto* player = static_cast<BitmapEmojiPlayer*>(arg);
    if (player && player->current_animation_.is_playing()) {
        player->DrawCurrentFrame();
        player->NextFrame();
    }
}

void BitmapEmojiPlayer::DrawCurrentFrame() {
    if (!current_animation_.is_valid()) {
        return;
    }
    
    const EmojiFrame& frame = current_animation_.frames()[current_animation_.current_frame()];
    if (frame.bitmap_data) {
        // 计算居中位置
        int x_offset = (128 - frame.width) / 2;
        int y_offset = (64 - frame.height) / 2;
        
        esp_lcd_panel_draw_bitmap(panel_, x_offset, y_offset, 
                                 x_offset + frame.width, y_offset + frame.height, 
                                 frame.bitmap_data);
    }
}

void BitmapEmojiPlayer::NextFrame() {
    if (current_animation_.frame_count() == 0) {
        return;
    }
    
    uint8_t next_frame = current_animation_.current_frame() + 1;
    current_animation_.set_current_frame(next_frame);
    
    // 检查是否需要循环
    if (next_frame >= current_animation_.frame_count()) {
        if (current_animation_.repeat()) {
            current_animation_.set_current_frame(0);
        } else {
            current_animation_.set_is_playing(false);
            esp_timer_stop(timer_);
        }
    }
}

// BitmapEmojiDisplay实现
BitmapEmojiDisplay::BitmapEmojiDisplay(esp_lcd_panel_handle_t panel, esp_lcd_panel_io_handle_t panel_io) {
    InitializePlayer(panel, panel_io);
    SetupEmotionMappings();
}

BitmapEmojiDisplay::~BitmapEmojiDisplay() {
    // 智能指针会自动清理
}

void BitmapEmojiDisplay::SetEmotion(const char* emotion) {
    if (!player_) {
        return;
    }
    
    EmojiAnimation animation = GetEmotionAnimation(emotion);
    if (animation.frames) {
        player_->PlayAnimation(animation);
        ESP_LOGI(TAG, "Set emotion: %s", emotion);
    } else {
        ESP_LOGW(TAG, "Unknown emotion: %s", emotion);
    }
}

void BitmapEmojiDisplay::SetStatus(const char* status) {
    if (!player_) {
        return;
    }
    
    EmojiAnimation animation = GetStatusAnimation(status);
    if (animation.frames) {
        player_->PlayAnimation(animation);
        ESP_LOGI(TAG, "Set status: %s", status);
    } else {
        ESP_LOGW(TAG, "Unknown status: %s", status);
    }
}

void BitmapEmojiDisplay::SetChatMessage(const char* role, const char* content) {
    // 对于SSD1306，我们简化处理，只显示思考表情
    if (player_) {
        EmojiAnimation thinking_anim(thinking_face, EMOJI_WIDTH, EMOJI_HEIGHT, 2000, false, 1);
        player_->PlayAnimation(thinking_anim);
    }
}

void BitmapEmojiDisplay::ShowNotification(const char* notification, int duration_ms) {
    // 显示通知时播放一个简单的动画
    if (player_) {
        // 创建两帧动画：开心表情 + 空白帧
        EmojiFrame frames[2] = {
            EmojiFrame(happy_face, EMOJI_WIDTH, EMOJI_HEIGHT, duration_ms / 2),
            EmojiFrame(nullptr, 0, 0, duration_ms / 2)  // 空白帧
        };
        EmojiAnimation notify_anim(frames, 2, false, 2);
        player_->PlayAnimation(notify_anim);
    }
}

void BitmapEmojiDisplay::SetTheme(const char* theme) {
    // SSD1306是单色显示，主题功能有限
    ESP_LOGI(TAG, "Theme set to: %s (limited support for monochrome display)", theme);
}

void BitmapEmojiDisplay::SetPowerSaveMode(bool on) {
    if (player_) {
        if (on) {
            player_->ClearScreen();
        }
        ESP_LOGI(TAG, "Power save mode: %s", on ? "ON" : "OFF");
    }
}

bool BitmapEmojiDisplay::Lock(int timeout_ms) {
    // 简单的互斥锁实现
    return true;
}

void BitmapEmojiDisplay::Unlock() {
    // 简单的互斥锁实现
}

void BitmapEmojiDisplay::InitializePlayer(esp_lcd_panel_handle_t panel, esp_lcd_panel_io_handle_t panel_io) {
    player_ = std::make_unique<BitmapEmojiPlayer>(panel, panel_io);
}

void BitmapEmojiDisplay::SetupEmotionMappings() {
    // 设置表情映射 - 使用构造函数和移动语义避免拷贝
    emotion_map_["happy"] = EmojiAnimation(happy_face, EMOJI_WIDTH, EMOJI_HEIGHT, 100, true, 10);
    emotion_map_["sad"] = EmojiAnimation(sad_face, EMOJI_WIDTH, EMOJI_HEIGHT, 100, true, 10);
    emotion_map_["thinking"] = EmojiAnimation(thinking_face, EMOJI_WIDTH, EMOJI_HEIGHT, 100, true, 10);
    
    // 5帧眨眼动画示例
    EmojiFrame blink_frames[5] = {
        EmojiFrame(blink_frame1, EMOJI_WIDTH, EMOJI_HEIGHT, 200),  // 睁眼
        EmojiFrame(blink_frame2, EMOJI_WIDTH, EMOJI_HEIGHT, 100),  // 半闭眼
        EmojiFrame(blink_frame3, EMOJI_WIDTH, EMOJI_HEIGHT, 100),  // 闭眼
        EmojiFrame(blink_frame4, EMOJI_WIDTH, EMOJI_HEIGHT, 100),  // 半闭眼
        EmojiFrame(blink_frame5, EMOJI_WIDTH, EMOJI_HEIGHT, 200)   // 睁眼
    };
    emotion_map_["blink"] = EmojiAnimation(blink_frames, 5, true, 15);
    
    // 添加更多表情...
}

EmojiAnimation BitmapEmojiDisplay::GetEmotionAnimation(const char* emotion) {
    auto it = emotion_map_.find(emotion);
    if (it != emotion_map_.end()) {
        return it->second;
    }
    return EmojiAnimation();  // 返回空动画
}

EmojiAnimation BitmapEmojiDisplay::GetStatusAnimation(const char* status) {
    auto it = status_map_.find(status);
    if (it != status_map_.end()) {
        return it->second;
    }
    return EmojiAnimation();  // 返回空动画
}

} // namespace bitmap_emoji
