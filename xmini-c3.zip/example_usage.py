#!/usr/bin/env python3
"""
图片转位图工具使用示例
演示如何使用image_to_bitmap.py工具
"""

import os
import sys
from PIL import Image, ImageDraw
import numpy as np

def create_sample_images():
    """创建一些示例图片用于演示"""
    
    # 创建示例目录
    os.makedirs("sample_images", exist_ok=True)
    
    # 1. 创建简单笑脸
    create_simple_smile()
    
    # 2. 创建悲伤脸
    create_sad_face()
    
    # 3. 创建思考脸
    create_thinking_face()
    
    print("示例图片已创建在 sample_images/ 目录中")

def create_simple_smile():
    """创建简单笑脸"""
    img = Image.new('RGB', (128, 64), color='white')
    draw = ImageDraw.Draw(img)
    
    # 画圆形脸
    draw.ellipse([20, 10, 108, 54], outline='black', width=2)
    
    # 画眼睛
    draw.ellipse([35, 20, 45, 30], fill='black')  # 左眼
    draw.ellipse([83, 20, 93, 30], fill='black')  # 右眼
    
    # 画嘴巴 (微笑)
    draw.arc([40, 35, 88, 50], start=0, end=180, fill='black', width=2)
    
    img.save("sample_images/simple_smile.png")
    print("创建: simple_smile.png")

def create_sad_face():
    """创建悲伤脸"""
    img = Image.new('RGB', (128, 64), color='white')
    draw = ImageDraw.Draw(img)
    
    # 画圆形脸
    draw.ellipse([20, 10, 108, 54], outline='black', width=2)
    
    # 画眼睛
    draw.ellipse([35, 20, 45, 30], fill='black')  # 左眼
    draw.ellipse([83, 20, 93, 30], fill='black')  # 右眼
    
    # 画嘴巴 (悲伤)
    draw.arc([40, 45, 88, 60], start=180, end=360, fill='black', width=2)
    
    img.save("sample_images/simple_sad.png")
    print("创建: simple_sad.png")

def create_thinking_face():
    """创建思考脸"""
    img = Image.new('RGB', (128, 64), color='white')
    draw = ImageDraw.Draw(img)
    
    # 画圆形脸
    draw.ellipse([20, 10, 108, 54], outline='black', width=2)
    
    # 画眼睛 (半闭)
    draw.arc([35, 22, 45, 28], start=0, end=180, fill='black', width=2)  # 左眼
    draw.arc([83, 22, 93, 28], start=0, end=180, fill='black', width=2)  # 右眼
    
    # 画嘴巴 (直线)
    draw.line([40, 40, 88, 40], fill='black', width=2)
    
    img.save("sample_images/simple_thinking.png")
    print("创建: simple_thinking.png")

def demonstrate_conversion():
    """演示转换过程"""
    
    print("\n=== 图片转位图演示 ===")
    
    # 导入转换函数
    sys.path.append('.')
    from image_to_bitmap import image_to_bitmap_array
    
    # 转换示例图片
    images = [
        ("sample_images/simple_smile.png", "happy_face", 120),
        ("sample_images/simple_sad.png", "sad_face", 120),
        ("sample_images/simple_thinking.png", "thinking_face", 120)
    ]
    
    print("\n生成的C语言数组:")
    print("=" * 50)
    
    for image_path, array_name, threshold in images:
        if os.path.exists(image_path):
            print(f"\n// 从 {image_path} 转换而来")
            try:
                # 修改输出以使用指定的数组名，并保存预览图片
                array_str = image_to_bitmap_array(image_path, threshold, None, save_preview=True)
                # 替换数组名
                array_str = array_str.replace("simple_smile", array_name)
                array_str = array_str.replace("simple_sad", array_name)
                array_str = array_str.replace("simple_thinking", array_name)
                print(array_str)
            except Exception as e:
                print(f"转换失败: {e}")
        else:
            print(f"文件不存在: {image_path}")
    
    print("\n预览图片已生成，可以查看转换效果！")

def create_emoji_data_file():
    """创建完整的emoji_data.cc文件"""
    
    print("\n=== 创建emoji_data.cc文件 ===")
    
    # 生成完整的C文件内容
    c_content = '''#include "emoji_data.h"

namespace bitmap_emoji {

// 注意：以下数组需要从实际转换的图片生成
// 这里只是示例结构

// 开心表情 - 需要从实际图片转换
const uint8_t happy_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_smile.png 120 生成
    // 然后将生成的数组复制到这里
};

// 悲伤表情 - 需要从实际图片转换  
const uint8_t sad_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_sad.png 120 生成
    // 然后将生成的数组复制到这里
};

// 思考表情 - 需要从实际图片转换
const uint8_t thinking_face[EMOJI_DATA_SIZE] = {
    // 使用 python image_to_bitmap.py sample_images/simple_thinking.png 120 生成
    // 然后将生成的数组复制到这里
};

// 眨眼动画 - 5帧动画示例
const uint8_t blink_frame1[EMOJI_DATA_SIZE] = {
    // 全亮帧 - 睁眼状态
};

const uint8_t blink_frame2[EMOJI_DATA_SIZE] = {
    // 半闭眼帧
};

const uint8_t blink_frame3[EMOJI_DATA_SIZE] = {
    // 闭眼帧
};

const uint8_t blink_frame4[EMOJI_DATA_SIZE] = {
    // 半闭眼帧
};

const uint8_t blink_frame5[EMOJI_DATA_SIZE] = {
    // 全亮帧 - 睁眼状态
};

} // namespace bitmap_emoji
'''
    
    with open("emoji_data_template.cc", "w", encoding="utf-8") as f:
        f.write(c_content)
    
    print("已创建: emoji_data_template.cc")
    print("请按照注释中的说明生成实际的位图数据")

def main():
    """主函数"""
    print("图片转位图工具使用示例")
    print("=" * 40)
    
    # 创建示例图片
    create_sample_images()
    
    # 演示转换过程
    demonstrate_conversion()
    
    # 创建模板文件
    create_emoji_data_file()
    
    print("\n=== 使用说明 ===")
    print("1. 查看生成的示例图片: sample_images/")
    print("2. 使用转换工具:")
    print("   python image_to_bitmap.py sample_images/simple_smile.png 120")
    print("3. 将生成的数组复制到 emoji_data.cc 中")
    print("4. 编译并测试")

if __name__ == "__main__":
    main()
